"""Desktop Kivy startup check, run in CI with Xvfb. Not an Android device test."""
from __future__ import annotations
import os
import sys
import tempfile
from pathlib import Path


def main() -> int:
    with tempfile.TemporaryDirectory(prefix='desitecmax-ui-') as temp:
        os.environ['KIVY_HOME'] = str(Path(temp) / 'kivy')
        os.environ['KIVY_NO_ARGS'] = '1'
        os.environ['KIVY_NO_CONSOLELOG'] = '0'
        from kivy.config import Config
        Config.set('graphics', 'width', '1280')
        Config.set('graphics', 'height', '800')
        Config.set('input', 'mouse', 'mouse,disable_multitouch')
        from kivy.clock import Clock
        from kivy.uix.image import Image
        from main import DesitecApp
        errors = []
        completed = []

        class SmokeApp(DesitecApp):
            @property
            def user_data_dir(self):
                return temp

            def on_start(self):
                Clock.schedule_once(check_startup, 2.2)

        app = SmokeApp()

        def check_startup(_):
            try:
                assert app.title == 'Desitec Max'
                assert set(app.root.screen_names) == {
                    'splash', 'project', 'sketch', 'imports', 'materials', 'email'
                }
                assert len(app.root.screens) == 6
                logos = [w for w in app.root.walk(restrict=False)
                         if isinstance(w, Image) and 'desitec_logo.png' in str(w.source)]
                assert logos, 'No logo images loaded'
                assert all(image.texture is not None for image in logos)
                project = app.root.get_screen('project')
                assert project.ids.project_date.text
                assert project.ids.project_time.text
                project.ids.lda.text = 'LDA-TESTE-INTERFACE'
                project_id = app.save_project(auto_email=False)
                assert app.db.get_project(project_id)['lda'] == 'LDA-TESTE-INTERFACE'
                material_id = app.db.upsert_catalog_material(
                    code='0001', description='Material de teste', unit='PC', lot='LOTE-01')
                app.db.add_catalog_material_to_project(project_id, material_id, 2)
                app.refresh_materials()
                assert '0001' in app.root.get_screen('materials').ids.project_materials_text.text
                for name in ('project', 'sketch', 'imports', 'materials', 'email', 'project'):
                    app.go(name)
                completed.append(True)
                out = os.environ.get('DESITEC_UI_SCREENSHOT')
                if out:
                    Path(out).parent.mkdir(parents=True, exist_ok=True)
                    Clock.schedule_once(lambda _dt: save_screenshot(out), 0.7)
                else:
                    app.stop()
            except Exception as exc:
                errors.append(exc)
                app.stop()

        def save_screenshot(out):
            try:
                app.root.export_to_png(out)
            except Exception as exc:
                errors.append(exc)
            finally:
                app.stop()

        app.run()
        if errors:
            raise RuntimeError('Kivy startup validation failed') from errors[0]
        if not completed:
            raise RuntimeError('Startup check did not complete')
        print('OK: Kivy startup, branding, database, materials and navigation (desktop only).')
        return 0


if __name__ == '__main__':
    sys.exit(main())
