"""Resolve uploaded sources before pytest/Buildozer; never suppress test errors.

This module is also embedded verbatim in the standalone GitHub workflow so that
mobile users can upload just the source ZIP and create one YAML file.
"""
from __future__ import annotations

import ast
import json
import hashlib
import os
from pathlib import Path, PurePosixPath
import stat
import tempfile
import zipfile

IGNORED = {'.git', '.github', '.buildozer', '.venv', '.venv-build',
           '__pycache__', '.pytest_cache', 'bin', 'dist', 'test-results'}
REQUIRED = ('main.py', 'buildozer.spec', 'desitec.kv', 'services/database.py',
            'tests/test_services.py', 'requirements-ci.txt', 'requirements-build.txt',
            'requirements-ui.txt', 'app_config.json', 'ci/smoke_ui.py',
            'assets/desitec_logo.png', 'assets/desitec_icon.png')


def project_candidates(base: Path) -> list[Path]:
    candidates = []
    for here, directories, filenames in os.walk(base, followlinks=False):
        directories[:] = [d for d in directories if d not in IGNORED
                          and not (Path(here) / d).is_symlink()]
        if 'main.py' in filenames and 'buildozer.spec' in filenames:
            candidates.append(Path(here).resolve())
    return sorted(set(candidates))


def unpack_safely(archive: Path, destination: Path) -> None:
    with zipfile.ZipFile(archive) as z:
        items = z.infolist()
        if len(items) > 10000 or sum(i.file_size for i in items) > 150 * 1024 * 1024:
            raise ValueError('ZIP excede o limite de tamanho desta compilacao.')
        seen = set()
        for item in items:
            name = item.filename
            relative = PurePosixPath(name)
            if (not name or '\\' in name or ':' in name or relative.is_absolute()
                    or '..' in relative.parts or any(ord(c) < 32 for c in name)):
                raise ValueError('Caminho inseguro no ZIP.')
            if stat.S_ISLNK(item.external_attr >> 16):
                raise ValueError('Links simbolicos nao sao aceitos no ZIP.')
            normalized = str(relative)
            if normalized in seen:
                raise ValueError('Caminho duplicado no ZIP.')
            seen.add(normalized)
        # Validate every entry before writing any data.
        for item in items:
            target = destination.joinpath(*PurePosixPath(item.filename).parts)
            if item.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(z.read(item))


def validate_project(project: Path) -> None:
    missing = [name for name in REQUIRED if not (project / name).is_file()]
    if missing:
        raise ValueError('Projeto incompleto ou antigo. Envie DesitecMax_Projeto.zip. '
                         'Arquivos ausentes: ' + ', '.join(missing))
    metadata = json.loads((project / 'app_config.json').read_text(encoding='utf-8'))
    if metadata.get('app_name') != 'Desitec Max':
        raise ValueError('Versao incorreta. Envie DesitecMax_Projeto.zip atualizado.')
    found = []
    for p in (project / 'tests').glob('test_*.py'):
        tree = ast.parse(p.read_text(encoding='utf-8'), filename=str(p))
        found.extend(node.name for node in tree.body
                     if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                     and node.name.startswith('test_'))
    if not found:
        raise ValueError('Nenhum teste test_* encontrado. Use o ZIP corrigido; '
                         'nao ignore o codigo de saida do pytest.')


def prepare(workspace: Path, runner_temp: Path) -> Path:
    workspace = workspace.resolve()
    runner_temp.mkdir(parents=True, exist_ok=True)
    archive = workspace / 'DesitecMax_Projeto.zip'
    if archive.is_file():
        if archive.is_symlink():
            raise ValueError('O ZIP deve ser um arquivo, nao um link.')
        stage = Path(tempfile.mkdtemp(prefix='desitec-source-', dir=runner_temp))
        unpack_safely(archive, stage)
        print('ZIP selecionado: DesitecMax_Projeto.zip')
        print('SHA256 do ZIP:', hashlib.sha256(archive.read_bytes()).hexdigest())
        candidates = project_candidates(stage)
    else:
        candidates = project_candidates(workspace)
    if not candidates:
        raise ValueError('Envie DesitecMax_Projeto.zip na raiz do repositorio. '
                         'Enviar so o workflow nao envia o aplicativo.')
    if len(candidates) != 1:
        raise ValueError('Ha mais de uma copia do app. Envie DesitecMax_Projeto.zip '
                         'na raiz para selecionar a versao corrigida sem apagar as antigas.')
    project = candidates[0]
    if any(ord(c) < 32 for c in str(project)):
        raise ValueError('Nome de pasta invalido.')
    validate_project(project)
    return project


if __name__ == '__main__':
    try:
        project = prepare(Path(os.environ.get('GITHUB_WORKSPACE', '.')),
                          Path(os.environ.get('RUNNER_TEMP', tempfile.gettempdir())))
    except (ValueError, OSError, SyntaxError, zipfile.BadZipFile) as exc:
        raise SystemExit('ERRO DE PREPARACAO: ' + str(exc))
    print('Pasta do projeto:', project)
    if os.environ.get('GITHUB_OUTPUT'):
        with open(os.environ['GITHUB_OUTPUT'], 'a', encoding='utf-8') as output:
            output.write(f'project_dir={project}\n')
