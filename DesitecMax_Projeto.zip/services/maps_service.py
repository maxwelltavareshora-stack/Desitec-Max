from __future__ import annotations

import webbrowser
from urllib.parse import urlencode


def google_maps_search_url(*, address: str = "", latitude: str = "", longitude: str = "") -> str:
    query = address.strip()
    if latitude.strip() and longitude.strip():
        query = f"{latitude.strip()},{longitude.strip()}"
    if not query:
        raise ValueError("Informe um endereço ou latitude/longitude.")
    return "https://www.google.com/maps/search/?" + urlencode({"api": "1", "query": query})


def google_maps_directions_url(*, destination: str, origin: str = "") -> str:
    if not destination.strip():
        raise ValueError("Informe o destino.")
    params = {"api": "1", "destination": destination.strip()}
    if origin.strip():
        params["origin"] = origin.strip()
    return "https://www.google.com/maps/dir/?" + urlencode(params)


def open_google_maps(*, address: str = "", latitude: str = "", longitude: str = "") -> str:
    url = google_maps_search_url(address=address, latitude=latitude, longitude=longitude)
    webbrowser.open(url)
    return url
