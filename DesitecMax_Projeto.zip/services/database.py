from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from datetime import datetime
from typing import Any, Iterable


SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS email_recipients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lda TEXT,
    ntc TEXT,
    item TEXT,
    address TEXT,
    zna TEXT,
    ks TEXT,
    project_date TEXT,
    project_time TEXT,
    latitude TEXT,
    longitude TEXT,
    cable_type TEXT,
    pole_type TEXT,
    structure_name TEXT,
    service_description TEXT,
    notes TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- Tabela legada da v0.2. É mantida para compatibilidade/migração.
CREATE TABLE IF NOT EXISTS materials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER,
    code TEXT,
    description TEXT,
    unit TEXT,
    lot TEXT,
    quantity REAL,
    source_file TEXT,
    source_sheet TEXT,
    source_row INTEGER,
    imported_at TEXT NOT NULL,
    FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE SET NULL
);

-- Biblioteca técnica global e reutilizável do Desitec.
CREATE TABLE IF NOT EXISTS material_catalog (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    unit TEXT NOT NULL DEFAULT '',
    lot TEXT NOT NULL DEFAULT '',
    reference_quantity REAL,
    source_file TEXT,
    source_sheet TEXT,
    source_row INTEGER,
    raw_json TEXT NOT NULL DEFAULT '{}',
    imported_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_material_catalog_identity
    ON material_catalog(code, description, unit, lot);
CREATE INDEX IF NOT EXISTS idx_material_catalog_code ON material_catalog(code);
CREATE INDEX IF NOT EXISTS idx_material_catalog_lot ON material_catalog(lot);
CREATE INDEX IF NOT EXISTS idx_material_catalog_description ON material_catalog(description);

-- Lista de materiais específica de cada serviço/projeto.
CREATE TABLE IF NOT EXISTS project_materials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    catalog_material_id INTEGER,
    code TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    unit TEXT NOT NULL DEFAULT '',
    lot TEXT NOT NULL DEFAULT '',
    quantity REAL NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY(catalog_material_id) REFERENCES material_catalog(id) ON DELETE SET NULL,
    UNIQUE(project_id, catalog_material_id)
);
CREATE INDEX IF NOT EXISTS idx_project_materials_project ON project_materials(project_id);

CREATE TABLE IF NOT EXISTS attachments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER,
    file_name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_type TEXT,
    extracted_text TEXT,
    metadata_json TEXT,
    imported_at TEXT NOT NULL,
    FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS imported_rows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER,
    source_file TEXT NOT NULL,
    source_sheet TEXT,
    row_number INTEGER,
    data_json TEXT NOT NULL,
    imported_at TEXT NOT NULL,
    FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS symbols (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    vector_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS croqui_objects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    object_type TEXT NOT NULL,
    data_json TEXT NOT NULL,
    z_index INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
);
"""


DEFAULT_SYMBOLS = [
    ("TRAFO_EXIST", "Transformador existente", "Transformadores", {"shape": "transformer", "filled": False, "install_mark": False}),
    ("TRAFO_SUB", "Substituição de transformador", "Transformadores", {"shape": "transformer", "filled": True, "install_mark": False}),
    ("TRAFO_INST", "Instalação de transformador", "Transformadores", {"shape": "transformer", "filled": True, "install_mark": True}),
    ("POSTE_EXIST", "Poste existente", "Postes", {"shape": "circle", "filled": False, "cross": False}),
    ("POSTE_INST", "Poste a instalar", "Postes", {"shape": "circle", "filled": True, "cross": False}),
    ("POSTE_RET", "Poste a retirar", "Postes", {"shape": "circle", "filled": False, "cross": True}),
    ("13CE1", "13CE1", "Estruturas", {"shape": "structure", "code": "13CE1"}),
    ("13CE2", "13CE2", "Estruturas", {"shape": "structure", "code": "13CE2"}),
    ("13CE3", "13CE3", "Estruturas", {"shape": "structure", "code": "13CE3"}),
    ("13CE4", "13CE4", "Estruturas", {"shape": "structure", "code": "13CE4"}),
    ("13B1", "13B1", "Estruturas", {"shape": "structure", "code": "13B1"}),
    ("13B2", "13B2", "Estruturas", {"shape": "structure", "code": "13B2"}),
    ("13B3", "13B3", "Estruturas", {"shape": "structure", "code": "13B3"}),
    ("34B1", "34B1", "Estruturas", {"shape": "structure", "code": "34B1"}),
    ("GLV", "GLV", "Proteção", {"shape": "glv"}),
    ("CHAVE_FUSIVEL", "Chave fusível", "Proteção", {"shape": "fuse_switch"}),
    ("ATERRAMENTO", "Aterramento", "Proteção", {"shape": "ground"}),
]


class Database:
    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self._seed_symbols()
        self._migrate_legacy_materials()

    def close(self):
        self.conn.close()

    @staticmethod
    def now() -> str:
        return datetime.now().isoformat(timespec="seconds")

    def _seed_symbols(self):
        now = self.now()
        self.conn.executemany(
            "INSERT OR IGNORE INTO symbols(code,name,category,vector_json,created_at) VALUES(?,?,?,?,?)",
            [(c, n, cat, json.dumps(v, ensure_ascii=False), now) for c, n, cat, v in DEFAULT_SYMBOLS],
        )
        self.conn.commit()

    def _migrate_legacy_materials(self):
        """Migra uma única vez os materiais da v0.2 para catálogo + lista do projeto."""
        if self.get_setting("materials_migrated_v03", False):
            return
        rows = self.conn.execute("SELECT * FROM materials ORDER BY id").fetchall()
        for row in rows:
            d = dict(row)
            catalog_id = self.upsert_catalog_material(
                code=d.get("code") or "",
                description=d.get("description") or "",
                unit=d.get("unit") or "",
                lot=d.get("lot") or "",
                reference_quantity=d.get("quantity"),
                source_file=d.get("source_file") or "",
                source_sheet=d.get("source_sheet") or "",
                source_row=d.get("source_row"),
                raw_data={"migrated_from": "materials_v02", **d},
                commit=False,
            )
            if d.get("project_id"):
                self.add_catalog_material_to_project(
                    int(d["project_id"]),
                    catalog_id,
                    quantity=d.get("quantity") if d.get("quantity") is not None else 1,
                    commit=False,
                )
        self.conn.commit()
        self.set_setting("materials_migrated_v03", True)

    def set_setting(self, key: str, value: Any):
        self.conn.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value, ensure_ascii=False)),
        )
        self.conn.commit()

    def get_setting(self, key: str, default: Any = None) -> Any:
        row = self.conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        if not row:
            return default
        try:
            return json.loads(row["value"])
        except Exception:
            return row["value"]

    def add_recipient(self, email: str):
        self.conn.execute(
            "INSERT OR IGNORE INTO email_recipients(email,active,created_at) VALUES(?,1,?)",
            (email.strip(), self.now()),
        )
        self.conn.commit()

    def remove_recipient(self, email: str):
        self.conn.execute("DELETE FROM email_recipients WHERE email=?", (email.strip(),))
        self.conn.commit()

    def list_recipients(self) -> list[str]:
        rows = self.conn.execute("SELECT email FROM email_recipients WHERE active=1 ORDER BY email").fetchall()
        return [r["email"] for r in rows]

    def save_project(self, data: dict[str, Any], project_id: int | None = None) -> int:
        fields = [
            "lda", "ntc", "item", "address", "zna", "ks", "project_date", "project_time",
            "latitude", "longitude", "cable_type", "pole_type", "structure_name",
            "service_description", "notes",
        ]
        now = self.now()
        values = [data.get(k, "") for k in fields]
        if project_id:
            assignments = ",".join(f"{f}=?" for f in fields)
            self.conn.execute(
                f"UPDATE projects SET {assignments}, updated_at=? WHERE id=?",
                (*values, now, project_id),
            )
            pid = project_id
        else:
            cols = ",".join(fields)
            qs = ",".join("?" for _ in fields)
            cur = self.conn.execute(
                f"INSERT INTO projects({cols},created_at,updated_at) VALUES({qs},?,?)",
                (*values, now, now),
            )
            pid = int(cur.lastrowid)
        self.conn.commit()
        return pid

    def get_project(self, project_id: int) -> dict[str, Any] | None:
        row = self.conn.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchone()
        return dict(row) if row else None

    def list_projects(self, limit: int = 50) -> list[dict[str, Any]]:
        rows = self.conn.execute("SELECT * FROM projects ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    # ---------- Biblioteca de materiais ----------
    def upsert_catalog_material(
        self,
        *,
        code: str = "",
        description: str = "",
        unit: str = "",
        lot: str = "",
        reference_quantity: float | None = None,
        source_file: str = "",
        source_sheet: str = "",
        source_row: int | None = None,
        raw_data: dict[str, Any] | None = None,
        commit: bool = True,
    ) -> int:
        code = str(code or "").strip()
        description = str(description or "").strip()
        unit = str(unit or "").strip()
        lot = str(lot or "").strip()
        now = self.now()
        row = self.conn.execute(
            "SELECT id FROM material_catalog WHERE code=? AND description=? AND unit=? AND lot=?",
            (code, description, unit, lot),
        ).fetchone()
        raw_json = json.dumps(raw_data or {}, ensure_ascii=False, default=str)
        if row:
            mid = int(row["id"])
            self.conn.execute(
                """UPDATE material_catalog
                   SET reference_quantity=?, source_file=?, source_sheet=?, source_row=?, raw_json=?, updated_at=?
                   WHERE id=?""",
                (reference_quantity, source_file, source_sheet, source_row, raw_json, now, mid),
            )
        else:
            cur = self.conn.execute(
                """INSERT INTO material_catalog(
                       code,description,unit,lot,reference_quantity,source_file,source_sheet,source_row,raw_json,imported_at,updated_at
                   ) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (code, description, unit, lot, reference_quantity, source_file, source_sheet, source_row, raw_json, now, now),
            )
            mid = int(cur.lastrowid)
        if commit:
            self.conn.commit()
        return mid

    def get_catalog_material(self, material_id: int) -> dict[str, Any] | None:
        row = self.conn.execute("SELECT * FROM material_catalog WHERE id=?", (material_id,)).fetchone()
        if not row:
            return None
        d = dict(row)
        try:
            d["raw"] = json.loads(d.get("raw_json") or "{}")
        except Exception:
            d["raw"] = {}
        return d

    def search_material_catalog(self, search: str = "", limit: int = 500) -> list[dict[str, Any]]:
        params: list[Any] = []
        where = ""
        if search.strip():
            like = f"%{search.strip()}%"
            where = " WHERE code LIKE ? OR description LIKE ? OR lot LIKE ? OR unit LIKE ? OR source_file LIKE ?"
            params.extend([like, like, like, like, like])
        params.append(limit)
        rows = self.conn.execute(
            f"""SELECT * FROM material_catalog{where}
                ORDER BY CASE WHEN code='' THEN 1 ELSE 0 END, code, lot, description
                LIMIT ?""",
            params,
        ).fetchall()
        return [dict(r) for r in rows]

    def catalog_count(self) -> int:
        return int(self.conn.execute("SELECT COUNT(*) AS c FROM material_catalog").fetchone()["c"])

    def add_catalog_material_to_project(self, project_id: int, catalog_material_id: int, quantity: float = 1, *, commit: bool = True) -> int:
        material = self.get_catalog_material(catalog_material_id)
        if not material:
            raise ValueError("Material não encontrado no catálogo.")
        try:
            quantity = float(quantity)
        except Exception as exc:
            raise ValueError("Quantidade inválida.") from exc
        if quantity <= 0:
            raise ValueError("A quantidade deve ser maior que zero.")
        now = self.now()
        self.conn.execute(
            """INSERT INTO project_materials(
                   project_id,catalog_material_id,code,description,unit,lot,quantity,created_at,updated_at
               ) VALUES(?,?,?,?,?,?,?,?,?)
               ON CONFLICT(project_id,catalog_material_id) DO UPDATE SET
                   quantity=project_materials.quantity + excluded.quantity,
                   code=excluded.code,
                   description=excluded.description,
                   unit=excluded.unit,
                   lot=excluded.lot,
                   updated_at=excluded.updated_at""",
            (
                project_id,
                catalog_material_id,
                material.get("code") or "",
                material.get("description") or "",
                material.get("unit") or "",
                material.get("lot") or "",
                quantity,
                now,
                now,
            ),
        )
        row = self.conn.execute(
            "SELECT id FROM project_materials WHERE project_id=? AND catalog_material_id=?",
            (project_id, catalog_material_id),
        ).fetchone()
        if commit:
            self.conn.commit()
        return int(row["id"])

    def list_project_materials(self, project_id: int) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            """SELECT * FROM project_materials WHERE project_id=?
               ORDER BY CASE WHEN code='' THEN 1 ELSE 0 END, code, lot, description""",
            (project_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    def update_project_material_quantity(self, project_material_id: int, quantity: float):
        quantity = float(quantity)
        if quantity <= 0:
            self.remove_project_material(project_material_id)
            return
        self.conn.execute(
            "UPDATE project_materials SET quantity=?,updated_at=? WHERE id=?",
            (quantity, self.now(), project_material_id),
        )
        self.conn.commit()

    def remove_project_material(self, project_material_id: int):
        self.conn.execute("DELETE FROM project_materials WHERE id=?", (project_material_id,))
        self.conn.commit()

    def clear_project_materials(self, project_id: int):
        self.conn.execute("DELETE FROM project_materials WHERE project_id=?", (project_id,))
        self.conn.commit()

    # Alias de compatibilidade com a v0.2.
    def add_material(self, project_id: int | None, *, code: str = "", description: str = "", unit: str = "", lot: str = "", quantity: float | None = None, source_file: str = "", source_sheet: str = "", source_row: int | None = None):
        mid = self.upsert_catalog_material(
            code=code, description=description, unit=unit, lot=lot,
            reference_quantity=quantity, source_file=source_file,
            source_sheet=source_sheet, source_row=source_row,
        )
        if project_id:
            self.add_catalog_material_to_project(project_id, mid, quantity if quantity is not None and quantity > 0 else 1)
        return mid

    def list_materials(self, project_id: int | None = None, search: str = "", limit: int = 500) -> list[dict[str, Any]]:
        if project_id:
            return self.list_project_materials(project_id)
        return self.search_material_catalog(search=search, limit=limit)

    # ---------- Documentos / imports ----------
    def add_attachment(self, project_id: int | None, file_name: str, file_path: str, file_type: str, extracted_text: str = "", metadata: dict[str, Any] | None = None) -> int:
        cur = self.conn.execute(
            """INSERT INTO attachments(project_id,file_name,file_path,file_type,extracted_text,metadata_json,imported_at)
               VALUES(?,?,?,?,?,?,?)""",
            (project_id, file_name, file_path, file_type, extracted_text, json.dumps(metadata or {}, ensure_ascii=False), self.now()),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def list_attachments(self, project_id: int | None = None) -> list[dict[str, Any]]:
        if project_id:
            rows = self.conn.execute("SELECT * FROM attachments WHERE project_id=? ORDER BY id DESC", (project_id,)).fetchall()
        else:
            rows = self.conn.execute("SELECT * FROM attachments ORDER BY id DESC LIMIT 200").fetchall()
        return [dict(r) for r in rows]

    def add_imported_row(self, project_id: int | None, source_file: str, source_sheet: str, row_number: int, data: dict[str, Any]):
        self.conn.execute(
            "INSERT INTO imported_rows(project_id,source_file,source_sheet,row_number,data_json,imported_at) VALUES(?,?,?,?,?,?)",
            (project_id, source_file, source_sheet, row_number, json.dumps(data, ensure_ascii=False, default=str), self.now()),
        )

    def commit(self):
        self.conn.commit()

    # ---------- Croqui ----------
    def save_croqui(self, project_id: int, objects: Iterable[dict[str, Any]]):
        self.conn.execute("DELETE FROM croqui_objects WHERE project_id=?", (project_id,))
        rows = []
        for idx, obj in enumerate(objects):
            rows.append((project_id, obj.get("type", "unknown"), json.dumps(obj, ensure_ascii=False), idx))
        if rows:
            self.conn.executemany(
                "INSERT INTO croqui_objects(project_id,object_type,data_json,z_index) VALUES(?,?,?,?)",
                rows,
            )
        self.conn.commit()

    def load_croqui(self, project_id: int) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT data_json FROM croqui_objects WHERE project_id=? ORDER BY z_index,id", (project_id,)
        ).fetchall()
        return [json.loads(r["data_json"]) for r in rows]

    def list_symbols(self) -> list[dict[str, Any]]:
        rows = self.conn.execute("SELECT * FROM symbols ORDER BY category,name").fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["vector"] = json.loads(d.pop("vector_json"))
            result.append(d)
        return result
