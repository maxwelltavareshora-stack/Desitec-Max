from __future__ import annotations

import mimetypes
import os
import re
import smtplib
from dataclasses import dataclass
from email.message import EmailMessage
from pathlib import Path
from typing import Iterable

from .database import Database


EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


@dataclass
class SMTPConfig:
    host: str = "smtp.gmail.com"
    port: int = 587
    username: str = ""
    password: str = ""
    from_name: str = "Desitec Max"
    use_tls: bool = True

    @classmethod
    def from_environment(cls, username: str = ""):
        return cls(
            host=os.getenv("DESITEC_SMTP_HOST", os.getenv("LEVTEC_SMTP_HOST", "smtp.gmail.com")),
            port=int(os.getenv("DESITEC_SMTP_PORT", os.getenv("LEVTEC_SMTP_PORT", "587"))),
            username=username or os.getenv("DESITEC_SMTP_USER", os.getenv("LEVTEC_SMTP_USER", "")),
            password=os.getenv("DESITEC_SMTP_PASSWORD", os.getenv("LEVTEC_SMTP_PASSWORD", "")),
            from_name=os.getenv("DESITEC_SMTP_FROM_NAME", os.getenv("LEVTEC_SMTP_FROM_NAME", "Desitec Max")),
            use_tls=os.getenv("DESITEC_SMTP_TLS", os.getenv("LEVTEC_SMTP_TLS", "1")) != "0",
        )


def validate_email(email: str) -> bool:
    return bool(EMAIL_RE.match(email.strip()))


def build_project_subject(project: dict) -> str:
    bits = [project.get("lda") or "LDA", project.get("ntc") or "NTC", f"ITEM {project.get('item') or '-'}"]
    return "Desitec | " + " | ".join(bits)


def build_project_body(project: dict) -> str:
    return f"""Prezados,

Segue levantamento de campo registrado no Desitec.

LDA: {project.get('lda','')}
NTC: {project.get('ntc','')}
ITEM: {project.get('item','')}
DATA: {project.get('project_date','')} {project.get('project_time','')}
ENDEREÇO: {project.get('address','')}
ZNA: {project.get('zna','')}
KS: {project.get('ks','')}
POSTE: {project.get('pole_type','')}
ESTRUTURA: {project.get('structure_name','')}
CABO: {project.get('cable_type','')}

SERVIÇO:
{project.get('service_description','')}

OBSERVAÇÕES:
{project.get('notes','')}

Atenciosamente,
Desitec
"""


def _attach_file(msg: EmailMessage, path: Path):
    ctype, encoding = mimetypes.guess_type(path.name)
    if ctype is None or encoding is not None:
        ctype = "application/octet-stream"
    maintype, subtype = ctype.split("/", 1)
    with path.open("rb") as f:
        msg.add_attachment(f.read(), maintype=maintype, subtype=subtype, filename=path.name)


def send_project_email(db: Database, project_id: int, config: SMTPConfig, recipients: Iterable[str] | None = None, extra_attachments: Iterable[str | Path] = ()) -> dict:
    project = db.get_project(project_id)
    if not project:
        raise ValueError("Projeto não encontrado.")

    recipients = list(recipients or db.list_recipients())
    recipients = [r.strip() for r in recipients if validate_email(r)]
    if not recipients:
        raise ValueError("Cadastre pelo menos um e-mail destinatário válido.")
    if not config.username:
        raise ValueError("Informe o e-mail remetente.")
    if not config.password:
        raise ValueError("Informe a credencial de e-mail para esta sessão.")

    msg = EmailMessage()
    msg["Subject"] = build_project_subject(project)
    msg["From"] = f"{config.from_name} <{config.username}>"
    msg["To"] = ", ".join(recipients)
    msg.set_content(build_project_body(project))

    seen = set()
    paths = []
    for row in db.list_attachments(project_id):
        p = Path(row["file_path"])
        if p.exists() and p.resolve() not in seen:
            paths.append(p)
            seen.add(p.resolve())
    for raw in extra_attachments:
        p = Path(raw)
        if p.exists() and p.resolve() not in seen:
            paths.append(p)
            seen.add(p.resolve())
    for p in paths:
        _attach_file(msg, p)

    with smtplib.SMTP(config.host, config.port, timeout=30) as smtp:
        smtp.ehlo()
        if config.use_tls:
            smtp.starttls()
            smtp.ehlo()
        smtp.login(config.username, config.password)
        smtp.send_message(msg)

    return {"recipients": recipients, "attachments": [p.name for p in paths], "subject": msg["Subject"]}
