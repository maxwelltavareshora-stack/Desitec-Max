from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from openpyxl import load_workbook
from pypdf import PdfReader

from .database import Database


def _norm(value: Any) -> str:
    text = str(value or "").strip().lower()
    repl = str.maketrans("áàâãéêíóôõúç", "aaaaeeiooouc")
    return re.sub(r"[^a-z0-9]+", " ", text.translate(repl)).strip()


SYNONYMS = {
    "code": {"codigo", "cod", "codigo material", "item material", "material codigo", "cod material"},
    "description": {"descricao", "descricao material", "material", "nome material", "denominacao", "descricao do material"},
    "unit": {"un", "und", "unidade", "u m", "um", "unid"},
    "quantity": {"qtd", "qtde", "quantidade", "quant", "qde"},
    "lot": {"lote", "n lote", "numero lote", "lote material", "lote de material"},
}


def _find_header(ws, max_scan_rows: int = 30):
    for row_idx in range(1, min(ws.max_row, max_scan_rows) + 1):
        values = [ws.cell(row=row_idx, column=c).value for c in range(1, ws.max_column + 1)]
        normalized = [_norm(v) for v in values]
        score = sum(any(n in aliases for aliases in SYNONYMS.values()) for n in normalized if n)
        if score >= 2:
            return row_idx, values
    return 1, [ws.cell(row=1, column=c).value for c in range(1, ws.max_column + 1)]


def _column_map(headers: list[Any]) -> dict[str, int]:
    result: dict[str, int] = {}
    for idx, raw in enumerate(headers):
        n = _norm(raw)
        for target, aliases in SYNONYMS.items():
            if n in aliases and target not in result:
                result[target] = idx
    return result


def _to_float(value: Any) -> float | None:
    if value in (None, ""):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace(" ", "")
    # tolera decimal em padrão brasileiro.
    if "," in text and "." not in text:
        text = text.replace(",", ".")
    try:
        return float(text)
    except Exception:
        return None


def import_excel(path: str | Path, db: Database, project_id: int | None = None) -> dict[str, Any]:
    """Importa Excel para o banco bruto e para a biblioteca técnica global.

    O catálogo é global: uma planilha pode ser importada uma única vez e seus
    materiais ficam disponíveis para qualquer serviço. Se `project_id` for
    informado, o arquivo continua vinculado ao serviço como anexo, mas os
    materiais reconhecidos não são automaticamente adicionados à lista do
    serviço; o usuário escolhe os itens e quantidades pela tela de materiais.
    """
    path = Path(path)
    wb = load_workbook(path, data_only=False, read_only=True)
    summary = {
        "file": path.name,
        "sheets": 0,
        "rows_saved": 0,
        "materials_saved": 0,
        "catalog_total": 0,
        "sheet_details": [],
    }

    for ws in wb.worksheets:
        header_row, headers = _find_header(ws)
        mapping = _column_map(headers)
        clean_headers = [str(h).strip() if h is not None else f"COL_{i+1}" for i, h in enumerate(headers)]
        sheet_rows = 0
        sheet_materials = 0
        for row_idx in range(header_row + 1, ws.max_row + 1):
            vals = [ws.cell(row=row_idx, column=c).value for c in range(1, ws.max_column + 1)]
            if not any(v not in (None, "") for v in vals):
                continue
            row_data = {clean_headers[i]: vals[i] for i in range(min(len(clean_headers), len(vals)))}
            db.add_imported_row(project_id, path.name, ws.title, row_idx, row_data)
            sheet_rows += 1

            def val(key: str):
                idx = mapping.get(key)
                return vals[idx] if idx is not None and idx < len(vals) else None

            if mapping.get("description") is not None or mapping.get("code") is not None:
                code = str(val("code") or "").strip()
                desc = str(val("description") or "").strip()
                # Evita guardar linhas decorativas/totais vazias como materiais.
                if code or desc:
                    db.upsert_catalog_material(
                        code=code,
                        description=desc,
                        unit=str(val("unit") or "").strip(),
                        lot=str(val("lot") or "").strip(),
                        reference_quantity=_to_float(val("quantity")),
                        source_file=path.name,
                        source_sheet=ws.title,
                        source_row=row_idx,
                        raw_data=row_data,
                        commit=False,
                    )
                    sheet_materials += 1
        db.commit()
        summary["sheets"] += 1
        summary["rows_saved"] += sheet_rows
        summary["materials_saved"] += sheet_materials
        summary["sheet_details"].append(
            {
                "sheet": ws.title,
                "header_row": header_row,
                "mapping": mapping,
                "rows": sheet_rows,
                "materials": sheet_materials,
            }
        )

    summary["catalog_total"] = db.catalog_count()
    db.add_attachment(project_id, path.name, str(path.resolve()), "excel", metadata=summary)
    return summary


def import_pdf(path: str | Path, db: Database, project_id: int | None = None) -> dict[str, Any]:
    path = Path(path)
    reader = PdfReader(str(path))
    pages = []
    for idx, page in enumerate(reader.pages, 1):
        try:
            text = page.extract_text() or ""
        except Exception as exc:
            text = f"[Falha na leitura da página {idx}: {exc}]"
        pages.append(text)
    full_text = "\n\n".join(pages)
    metadata = {"pages": len(reader.pages), "characters": len(full_text)}
    db.add_attachment(project_id, path.name, str(path.resolve()), "pdf", extracted_text=full_text, metadata=metadata)
    return {"file": path.name, **metadata, "preview": full_text[:1800]}


def search_imported_rows(db: Database, term: str, limit: int = 100) -> list[dict[str, Any]]:
    like = f"%{term}%"
    rows = db.conn.execute(
        "SELECT * FROM imported_rows WHERE data_json LIKE ? ORDER BY id DESC LIMIT ?", (like, limit)
    ).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["data"] = json.loads(d.pop("data_json"))
        out.append(d)
    return out
