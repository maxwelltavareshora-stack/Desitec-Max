from __future__ import annotations

from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .database import Database


def export_project_materials_xlsx(db: Database, project_id: int, output_path: str | Path) -> Path:
    project = db.get_project(project_id)
    if not project:
        raise ValueError("Projeto não encontrado.")
    rows = db.list_project_materials(project_id)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    ws = wb.active
    ws.title = "Materiais"
    ws.sheet_view.showGridLines = False

    title = f"LEVTEC - LISTA DE MATERIAIS - {project.get('lda') or ''} NTC {project.get('ntc') or ''} ITEM {project.get('item') or ''}".strip()
    ws.merge_cells("A1:E1")
    ws["A1"] = title
    ws["A1"].font = Font(bold=True, size=14, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor="17395C")
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 24

    headers = ["CÓDIGO", "DESCRIÇÃO", "UNIDADE", "LOTE", "QUANTIDADE"]
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=3, column=col, value=header)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="0F4C81")
        cell.alignment = Alignment(horizontal="center", vertical="center")

    for r_idx, row in enumerate(rows, 4):
        values: list[Any] = [row["code"], row["description"], row["unit"], row["lot"], row["quantity"]]
        for c_idx, value in enumerate(values, 1):
            cell = ws.cell(row=r_idx, column=c_idx, value=value)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            # Dados vinculados/importados em verde, seguindo a convenção de planilhas.
            cell.font = Font(color="008000" if c_idx <= 4 else "0000FF")

    widths = {1: 16, 2: 58, 3: 12, 4: 18, 5: 14}
    for idx, width in widths.items():
        ws.column_dimensions[get_column_letter(idx)].width = width
    ws.freeze_panes = "A4"
    ws.auto_filter.ref = f"A3:E{max(3, 3 + len(rows))}"

    wb.save(output_path)
    return output_path
