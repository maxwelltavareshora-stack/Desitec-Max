from __future__ import annotations

import os
import shutil
from datetime import datetime
from pathlib import Path

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.lang import Builder
from kivy.properties import NumericProperty, StringProperty
from kivy.resources import resource_add_path
from kivy.uix.screenmanager import ScreenManager, Screen, FadeTransition
from kivy.utils import platform

from services.database import Database
from services.importers import import_excel, import_pdf
from services.maps_service import open_google_maps
from services.emailer import SMTPConfig, send_project_email, validate_email
from services.materials_export import export_project_materials_xlsx
from widgets.sketch import SketchCanvas

try:
    from plyer import filechooser, gps
except Exception:
    filechooser = None
    gps = None

APP_DIR = Path(__file__).resolve().parent
KV_PATH = APP_DIR / "desitec.kv"
resource_add_path(str(APP_DIR))


class RootManager(ScreenManager):
    pass


class NamedScreen(Screen):
    pass


class DesitecApp(App):
    current_project_id = NumericProperty(0)
    clock_text = StringProperty("")
    status_text = StringProperty("Pronto.")
    last_selected_file = StringProperty("")

    def load_kv(self, filename=None):
        # App.run() normally auto-loads desitec.kv before build(). Our build()
        # initializes the database first, then loads KV exactly once.
        return False

    def build(self):
        self.title = "Desitec Max"
        self.icon = str(APP_DIR / "assets/desitec_icon.png")
        # Tamanho mínimo só no desktop. No Android, a janela é controlada pelo sistema.
        if platform not in ("android", "ios"):
            Window.minimum_width = 1000
            Window.minimum_height = 700
        Window.clearcolor = (0.95, 0.97, 0.99, 1)
        data_dir = Path(self.user_data_dir)
        data_dir.mkdir(parents=True, exist_ok=True)
        new_db = data_dir / "desitec.db"
        legacy_db = data_dir / "levtec.db"
        if not new_db.exists() and legacy_db.exists():
            shutil.copy2(legacy_db, new_db)
        self.db = Database(new_db)
        self._material_option_map = {}
        self._project_material_option_map = {}
        self.root = Builder.load_file(str(KV_PATH))
        self.root.transition = FadeTransition(duration=0.28)
        Clock.schedule_interval(self._tick_clock, 1)
        self._tick_clock(0)
        Clock.schedule_once(lambda *_: self.refresh_recipients(), .2)
        Clock.schedule_once(lambda *_: self.go("project"), 1.6)
        Clock.schedule_once(lambda *_: self.refresh_materials(), .2)
        self._load_settings()
        return self.root

    def on_stop(self):
        if hasattr(self, "db"):
            self.db.close()

    def _tick_clock(self, *_):
        now = datetime.now()
        self.clock_text = now.strftime("%d/%m/%Y  %H:%M:%S")
        if self.root:
            project = self.root.get_screen("project")
            if not project.ids.project_date.text:
                project.ids.project_date.text = now.strftime("%d/%m/%Y")
            if not project.ids.project_time.text:
                project.ids.project_time.text = now.strftime("%H:%M")

    def go(self, screen_name: str):
        self.root.current = screen_name

    def set_status(self, text: str):
        self.status_text = text

    def _project_data(self):
        ids = self.root.get_screen("project").ids
        return {
            "lda": ids.lda.text.strip(),
            "ntc": ids.ntc.text.strip(),
            "item": ids.item.text.strip(),
            "address": ids.address.text.strip(),
            "zna": ids.zna.text.strip(),
            "ks": ids.ks.text.strip(),
            "project_date": ids.project_date.text.strip(),
            "project_time": ids.project_time.text.strip(),
            "latitude": ids.latitude.text.strip(),
            "longitude": ids.longitude.text.strip(),
            "cable_type": ids.cable_type.text.strip(),
            "pole_type": ids.pole_type.text.strip(),
            "structure_name": ids.structure_name.text.strip(),
            "service_description": ids.service_description.text.strip(),
            "notes": ids.notes.text.strip(),
        }

    def save_project(self, auto_email: bool | None = None):
        pid = self.db.save_project(self._project_data(), self.current_project_id or None)
        self.current_project_id = pid
        self.db.save_croqui(pid, self.root.get_screen("sketch").ids.sketch_canvas.serialize())
        self.refresh_project_materials()
        self.set_status(f"Serviço #{pid} salvo no banco de dados.")
        enabled = self.db.get_setting("auto_send_email", False) if auto_email is None else auto_email
        if enabled:
            try:
                self.send_current_email()
            except Exception as exc:
                self.set_status(f"Serviço salvo, mas o e-mail não foi enviado: {exc}")
        return pid

    def new_project(self):
        self.current_project_id = 0
        ids = self.root.get_screen("project").ids
        for key in ["lda","ntc","item","address","zna","ks","latitude","longitude","cable_type","pole_type","structure_name","service_description","notes"]:
            ids[key].text = ""
        now = datetime.now()
        ids.project_date.text = now.strftime("%d/%m/%Y")
        ids.project_time.text = now.strftime("%H:%M")
        self.root.get_screen("sketch").ids.sketch_canvas.clear_objects()
        self.refresh_project_materials()
        self.set_status("Novo serviço iniciado.")

    def open_maps(self):
        ids = self.root.get_screen("project").ids
        try:
            url = open_google_maps(address=ids.address.text, latitude=ids.latitude.text, longitude=ids.longitude.text)
            self.set_status("Google Maps aberto: " + url)
        except Exception as exc:
            self.set_status(str(exc))

    def request_current_location(self):
        if gps is None:
            self.set_status("GPS indisponível neste ambiente. No Android, instale/ative o Plyer e dê permissão de localização.")
            return
        try:
            try:
                from android.permissions import request_permissions, Permission
                request_permissions([Permission.ACCESS_FINE_LOCATION, Permission.ACCESS_COARSE_LOCATION])
            except Exception:
                pass
            gps.configure(on_location=self._on_location, on_status=lambda *_: None)
            gps.start(minTime=1000, minDistance=0)
            self.set_status("Buscando localização atual...")
        except Exception as exc:
            self.set_status(f"Não foi possível iniciar o GPS: {exc}")

    def _on_location(self, **kwargs):
        lat = kwargs.get("lat", kwargs.get("latitude"))
        lon = kwargs.get("lon", kwargs.get("longitude"))
        if lat is None or lon is None:
            return
        def apply(*_):
            ids = self.root.get_screen("project").ids
            ids.latitude.text = str(lat)
            ids.longitude.text = str(lon)
            self.set_status(f"Localização capturada: {lat}, {lon}")
            try:
                gps.stop()
            except Exception:
                pass
        Clock.schedule_once(apply, 0)

    def choose_file(self, kind: str):
        if filechooser is None:
            self.set_status("Seletor de arquivos indisponível. Digite o caminho do arquivo no campo de importação.")
            return
        filters = [("Excel", "*.xlsx", "*.xlsm")] if kind == "excel" else [("PDF", "*.pdf")]
        try:
            filechooser.open_file(on_selection=lambda sel: self._file_selected(sel, kind), filters=filters, multiple=False)
        except Exception as exc:
            self.set_status(f"Falha ao abrir seletor: {exc}")

    def _file_selected(self, selection, kind):
        if not selection:
            return
        path = selection[0]
        self.last_selected_file = path
        Clock.schedule_once(lambda *_: self._import_path(path, kind), 0)

    def import_from_text_field(self, kind: str):
        path = self.root.get_screen("imports").ids.import_path.text.strip()
        self._import_path(path, kind)

    def _import_path(self, path: str, kind: str):
        p = Path(path)
        if not p.exists():
            self.set_status("Arquivo não encontrado.")
            return
        try:
            if kind == "excel":
                summary = import_excel(p, self.db, self.current_project_id or None)
                message = f"Excel importado: {summary['rows_saved']} linhas salvas; {summary['materials_saved']} materiais reconhecidos; {summary['catalog_total']} itens no catálogo."
                self.root.get_screen("imports").ids.import_result.text = message + "\n\n" + str(summary)
                self.refresh_materials()
            else:
                summary = import_pdf(p, self.db, self.current_project_id or None)
                message = f"PDF importado: {summary['pages']} páginas; {summary['characters']} caracteres lidos."
                self.root.get_screen("imports").ids.import_result.text = message + "\n\nPRÉVIA:\n" + summary.get("preview", "")
            self.root.get_screen("imports").ids.import_path.text = str(p)
            self.set_status(message)
        except Exception as exc:
            self.set_status(f"Falha na importação: {exc}")

    def refresh_materials(self, search: str = ""):
        """Atualiza catálogo pesquisável e lista do serviço atual."""
        self.refresh_material_catalog(search)
        self.refresh_project_materials()

    def refresh_material_catalog(self, search: str = ""):
        if not self.root:
            return
        rows = self.db.search_material_catalog(search=search, limit=500)
        self._material_option_map = {}
        values = []
        lines = ["ID | CÓDIGO | DESCRIÇÃO | UN | LOTE | QTD REF. | ORIGEM"]
        for r in rows:
            qty = "" if r["reference_quantity"] is None else f"{r['reference_quantity']:g}"
            display = f"#{r['id']} | {r['code'] or 'S/C'} | lote {r['lot'] or '-'} | {(r['description'] or '')[:55]}"
            self._material_option_map[display] = int(r["id"])
            values.append(display)
            lines.append(
                f"{r['id']} | {r['code']} | {r['description']} | {r['unit']} | {r['lot']} | {qty} | {r['source_file']} / {r['source_sheet']}"
            )
        try:
            screen = self.root.get_screen("materials")
            screen.ids.material_catalog_text.text = "\n".join(lines)
            screen.ids.material_picker.values = values
            screen.ids.catalog_count.text = f"Catálogo: {len(rows)} exibidos / {self.db.catalog_count()} cadastrados"
            if values and screen.ids.material_picker.text not in self._material_option_map:
                screen.ids.material_picker.text = values[0]
                self.on_catalog_material_selected(values[0])
            elif not values:
                screen.ids.material_picker.text = "Nenhum material encontrado"
                screen.ids.material_details.text = ""
        except Exception:
            pass

    def on_catalog_material_selected(self, display_text: str):
        material_id = getattr(self, "_material_option_map", {}).get(display_text)
        if not material_id or not self.root:
            return
        row = self.db.get_catalog_material(material_id)
        if not row:
            return
        screen = self.root.get_screen("materials")
        qty = row.get("reference_quantity")
        screen.ids.material_qty.text = f"{qty:g}" if isinstance(qty, (int, float)) and qty > 0 else "1"
        raw = row.get("raw") or {}
        extras = []
        for key, value in raw.items():
            if value not in (None, "") and str(key).lower() not in {"código", "codigo", "descrição", "descricao", "unidade", "un", "quantidade", "qtd", "lote"}:
                extras.append(f"{key}: {value}")
        screen.ids.material_details.text = (
            f"Código: {row.get('code','')}\nDescrição: {row.get('description','')}\n"
            f"Unidade: {row.get('unit','')}    Lote: {row.get('lot','')}    Qtd. referência: {qty if qty is not None else '-'}\n"
            f"Origem: {row.get('source_file','')} / {row.get('source_sheet','')} / linha {row.get('source_row') or '-'}"
            + ("\n" + " | ".join(extras[:8]) if extras else "")
        )

    def add_selected_material_to_project(self):
        if not self.root:
            return
        screen = self.root.get_screen("materials")
        material_id = self._material_option_map.get(screen.ids.material_picker.text)
        if not material_id:
            self.set_status("Selecione um material do catálogo.")
            return
        if not self.current_project_id:
            self.save_project(auto_email=False)
        try:
            qty_text = screen.ids.material_qty.text.strip().replace(",", ".")
            qty = float(qty_text)
            self.db.add_catalog_material_to_project(int(self.current_project_id), material_id, qty)
            self.refresh_project_materials()
            self.set_status("Material adicionado à lista do serviço. Itens repetidos são somados automaticamente.")
        except Exception as exc:
            self.set_status(f"Não foi possível adicionar o material: {exc}")

    def refresh_project_materials(self):
        if not self.root:
            return
        try:
            screen = self.root.get_screen("materials")
        except Exception:
            return
        self._project_material_option_map = {}
        if not self.current_project_id:
            screen.ids.project_materials_text.text = "Salve ou inicie um serviço para montar a lista de materiais."
            screen.ids.project_material_picker.values = []
            screen.ids.project_material_picker.text = "Nenhum item no serviço"
            screen.ids.materials_project_info.text = "Serviço atual: ainda não salvo"
            return
        project = self.db.get_project(int(self.current_project_id)) or {}
        rows = self.db.list_project_materials(int(self.current_project_id))
        title = f"Serviço #{self.current_project_id} • {project.get('lda','')} • NTC {project.get('ntc','')} • Item {project.get('item','')}"
        screen.ids.materials_project_info.text = title
        lines = ["CÓDIGO | DESCRIÇÃO | UN | LOTE | QUANTIDADE"]
        values = []
        for r in rows:
            lines.append(f"{r['code']} | {r['description']} | {r['unit']} | {r['lot']} | {r['quantity']:g}")
            display = f"#{r['id']} | {r['code'] or 'S/C'} | lote {r['lot'] or '-'} | {(r['description'] or '')[:45]} | qtd {r['quantity']:g}"
            values.append(display)
            self._project_material_option_map[display] = int(r["id"])
        screen.ids.project_materials_text.text = "\n".join(lines) if rows else "Nenhum material adicionado ao serviço."
        screen.ids.project_material_picker.values = values
        screen.ids.project_material_picker.text = values[0] if values else "Nenhum item no serviço"

    def remove_selected_project_material(self):
        screen = self.root.get_screen("materials")
        row_id = self._project_material_option_map.get(screen.ids.project_material_picker.text)
        if not row_id:
            self.set_status("Selecione um item da lista do serviço.")
            return
        self.db.remove_project_material(row_id)
        self.refresh_project_materials()
        self.set_status("Material removido da lista do serviço.")

    def clear_current_project_materials(self):
        if not self.current_project_id:
            return
        self.db.clear_project_materials(int(self.current_project_id))
        self.refresh_project_materials()
        self.set_status("Lista de materiais do serviço limpa.")

    def export_current_project_materials(self):
        if not self.current_project_id:
            self.save_project(auto_email=False)
        project = self.db.get_project(int(self.current_project_id)) or {}
        export_dir = Path(self.user_data_dir) / "exports"
        export_dir.mkdir(parents=True, exist_ok=True)
        def clean(value):
            value = str(value or "").strip().replace("/", "-").replace("\\", "-")
            return "_".join(value.split())
        filename = f"MATERIAIS_{clean(project.get('lda')) or 'LDA'}_{clean(project.get('ntc')) or 'NTC'}_ITEM-{clean(project.get('item')) or 'ITEM'}.xlsx"
        output = export_project_materials_xlsx(self.db, int(self.current_project_id), export_dir / filename)
        self.set_status(f"Lista de materiais exportada: {output}")
        try:
            self.root.get_screen("materials").ids.export_path.text = str(output)
        except Exception:
            pass
        return output

    def add_recipient(self):
        field = self.root.get_screen("email").ids.recipient_input
        email = field.text.strip()
        if not validate_email(email):
            self.set_status("E-mail destinatário inválido.")
            return
        self.db.add_recipient(email)
        field.text = ""
        self.refresh_recipients()
        self.set_status("Destinatário cadastrado.")

    def remove_recipient(self):
        field = self.root.get_screen("email").ids.recipient_input
        email = field.text.strip()
        if email:
            self.db.remove_recipient(email)
            field.text = ""
            self.refresh_recipients()
            self.set_status("Destinatário removido, se existia.")

    def refresh_recipients(self):
        if not self.root:
            return
        recipients = self.db.list_recipients()
        self.root.get_screen("email").ids.recipient_list.text = "\n".join(recipients) if recipients else "Nenhum destinatário cadastrado."

    def save_email_settings(self):
        ids = self.root.get_screen("email").ids
        try:
            port = int(ids.smtp_port.text or "587")
            if not 1 <= port <= 65535:
                raise ValueError()
        except ValueError:
            self.set_status("Porta SMTP inválida. Use um número de 1 a 65535.")
            return
        self.db.set_setting("smtp_host", ids.smtp_host.text.strip() or "smtp.gmail.com")
        self.db.set_setting("smtp_port", port)
        self.db.set_setting("smtp_user", ids.smtp_user.text.strip())
        self.db.set_setting("auto_send_email", bool(ids.auto_send.active))
        self.set_status("Configurações de e-mail salvas. A senha fica apenas nesta sessão.")

    def _load_settings(self):
        if not self.root:
            return
        ids = self.root.get_screen("email").ids
        ids.smtp_host.text = str(self.db.get_setting("smtp_host", "smtp.gmail.com"))
        ids.smtp_port.text = str(self.db.get_setting("smtp_port", 587))
        ids.smtp_user.text = str(self.db.get_setting("smtp_user", ""))
        ids.auto_send.active = bool(self.db.get_setting("auto_send_email", False))

    def send_current_email(self):
        if not self.current_project_id:
            self.save_project(auto_email=False)
        ids = self.root.get_screen("email").ids
        config = SMTPConfig(
            host=ids.smtp_host.text.strip() or "smtp.gmail.com",
            port=int(ids.smtp_port.text or "587"),
            username=ids.smtp_user.text.strip(),
            password=ids.smtp_password.text,
            from_name="Desitec Max",
            use_tls=True,
        )
        extra_attachments = []
        if self.db.list_project_materials(int(self.current_project_id)):
            project = self.db.get_project(int(self.current_project_id)) or {}
            export_dir = Path(self.user_data_dir) / "exports"
            export_dir.mkdir(parents=True, exist_ok=True)
            def clean(value):
                return "_".join(str(value or "").strip().replace("/", "-").replace("\\", "-").split())
            material_file = export_dir / f"MATERIAIS_{clean(project.get('lda')) or 'LDA'}_{clean(project.get('ntc')) or 'NTC'}_ITEM-{clean(project.get('item')) or 'ITEM'}.xlsx"
            export_project_materials_xlsx(self.db, int(self.current_project_id), material_file)
            extra_attachments.append(material_file)
        result = send_project_email(self.db, int(self.current_project_id), config, extra_attachments=extra_attachments)
        self.set_status(f"E-mail enviado para {', '.join(result['recipients'])} com {len(result['attachments'])} anexo(s).")
        return result

    def set_sketch_tool(self, tool: str):
        canvas = self.root.get_screen("sketch").ids.sketch_canvas
        canvas.tool = tool
        self.root.get_screen("sketch").ids.sketch_status.text = f"Ferramenta: {tool}"

    def set_symbol(self, code: str):
        canvas = self.root.get_screen("sketch").ids.sketch_canvas
        canvas.tool = "symbol"
        canvas.symbol_code = code
        self.root.get_screen("sketch").ids.sketch_status.text = f"Símbolo: {code}"


if __name__ == "__main__":
    DesitecApp().run()
