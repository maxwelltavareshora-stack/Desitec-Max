[app]
title = Desitec Max
# Preserve the installed app identifier; only its display name changes.
package.name = desitec
package.domain = br.com
source.dir = .
source.include_exts = py,kv,png,jpg,jpeg,json,xlsx,xlsm,pdf,txt
source.exclude_dirs = tests,ci,docs,__pycache__,.git,.github,.venv,.venv-build,.pytest_cache,dist,test-results
version = 0.8.0
requirements = python3,kivy==2.3.1,openpyxl==3.1.5,et_xmlfile==2.0.0,pypdf==5.9.0,plyer==2.1.0
orientation = landscape
fullscreen = 0
icon.filename = assets/desitec_icon.png
icon.adaptive_foreground.filename = assets/desitec_icon_foreground.png
icon.adaptive_background.filename = assets/desitec_icon_background.png
presplash.filename = assets/desitec_presplash.png
android.presplash_color = #031428
android.permissions = INTERNET,ACCESS_FINE_LOCATION,ACCESS_COARSE_LOCATION,READ_EXTERNAL_STORAGE
android.api = 35
android.minapi = 24
android.ndk = 28c
android.ndk_api = 24
android.archs = arm64-v8a,armeabi-v7a
android.accept_sdk_license = True
android.enable_androidx = True
android.logcat_filters = *:S python:D AndroidRuntime:E
# Pin the stable recipe release instead of silently changing with master.
p4a.branch = master
p4a.commit = v2026.05.09
p4a.bootstrap = sdl2

[buildozer]
log_level = 2
warn_on_root = 1
