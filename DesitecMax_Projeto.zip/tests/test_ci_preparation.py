"""Regression checks for uploads from mobile; independent of Android tools."""
from pathlib import Path
from zipfile import ZipFile

import pytest
from ci.prepare_project import REQUIRED, prepare, unpack_safely


def make_project(root):
    for name in REQUIRED:
        p = root / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text('# test fixture\n', encoding='utf-8')
    (root / 'tests/test_services.py').write_text(
        'def test_fixture():\n    assert True\n', encoding='utf-8')
    (root / 'app_config.json').write_text('{"app_name": "Desitec Max"}')
    return root


def test_ci_finds_flat_sources(tmp_path):
    workspace = make_project(tmp_path / 'repo')
    assert prepare(workspace, tmp_path / 'runner') == workspace


def test_ci_finds_nested_sources(tmp_path):
    workspace = tmp_path / 'repo'
    project = make_project(workspace / 'Desitec')
    assert prepare(workspace, tmp_path / 'runner') == project


def test_ci_zip_has_priority_over_old_sources(tmp_path):
    workspace = make_project(tmp_path / 'repo')
    fixed = make_project(tmp_path / 'corrected')
    with ZipFile(workspace / 'DesitecMax_Projeto.zip', 'w') as z:
        for p in fixed.rglob('*'):
            if p.is_file():
                z.write(p, 'Desitec/' + str(p.relative_to(fixed)))
    selected = prepare(workspace, tmp_path / 'runner')
    assert selected != workspace
    assert selected.name == 'Desitec'


def test_ci_reports_missing_sources(tmp_path):
    workspace = tmp_path / 'repo'
    workspace.mkdir()
    with pytest.raises(ValueError, match='Envie DesitecMax_Projeto.zip'):
        prepare(workspace, tmp_path / 'runner')


def test_ci_rejects_unrecognized_tests(tmp_path):
    workspace = make_project(tmp_path / 'repo')
    (workspace / 'tests/test_services.py').write_text('def run():\n    pass\n')
    with pytest.raises(ValueError, match='Nenhum teste'):
        prepare(workspace, tmp_path / 'runner')


def test_ci_rejects_ambiguous_sources(tmp_path):
    workspace = tmp_path / 'repo'
    make_project(workspace / 'old')
    make_project(workspace / 'new')
    with pytest.raises(ValueError, match='mais de uma copia'):
        prepare(workspace, tmp_path / 'runner')


def test_ci_rejects_zip_path_traversal(tmp_path):
    archive = tmp_path / 'bad.zip'
    with ZipFile(archive, 'w') as z:
        z.writestr('../outside.txt', 'unsafe')
    stage = tmp_path / 'stage'
    stage.mkdir()
    with pytest.raises(ValueError, match='inseguro'):
        unpack_safely(archive, stage)
    assert not (tmp_path / 'outside.txt').exists()
