"""Offline regression tests; no real emails, GPS calls or network requests."""
from pathlib import Path
from urllib.parse import parse_qs, urlparse
import configparser
import json

import pytest
from openpyxl import Workbook

from services.database import Database
from services.importers import import_excel, search_imported_rows
from services.maps_service import google_maps_search_url, google_maps_directions_url
from services.emailer import validate_email, build_project_body


@pytest.mark.parametrize('email,expected', [
    ('tecnico@example.com', True),
    ('tecnico+campo@example.com.br', True),
    ('sem-arroba', False),
    ('nome com espaco@example.com', False),
])
def test_email_validation(email, expected):
    assert validate_email(email) is expected


def test_maps_coordinates_take_priority():
    params = parse_qs(urlparse(google_maps_search_url(
        address='Rua de teste', latitude='-22.9', longitude='-43.2'
    )).query)
    assert params == {'api': ['1'], 'query': ['-22.9,-43.2']}


def test_maps_requires_location():
    with pytest.raises(ValueError):
        google_maps_search_url()


def test_maps_directions_preserve_accents():
    destination = 'Rua Capit\u00e3o Rezende'
    params = parse_qs(urlparse(google_maps_directions_url(destination=destination)).query)
    assert params['destination'] == [destination]


def test_project_and_sketch_survive_reopen(tmp_path):
    path = tmp_path / 'desitec.db'
    db = Database(path)
    objects = [{'type': 'symbol', 'code': 'TRAFO_EXIST', 'x': 20, 'y': 30}]
    try:
        pid = db.save_project({'lda': 'LDA-TESTE', 'project_date': '20/09/2026', 'project_time': '17:00'})
        db.save_croqui(pid, objects)
    finally:
        db.close()
    reopened = Database(path)
    try:
        assert reopened.get_project(pid)['lda'] == 'LDA-TESTE'
        assert reopened.load_croqui(pid) == objects
    finally:
        reopened.close()


def test_material_lots_are_not_merged(tmp_path):
    db = Database(tmp_path / 'desitec.db')
    try:
        pid = db.save_project({'lda': 'LDA-TESTE'})
        common = {'code': '00123', 'description': 'Cabo de teste', 'unit': 'M'}
        first = db.upsert_catalog_material(**common, lot='L01')
        second = db.upsert_catalog_material(**common, lot='L02')
        assert first != second
        db.add_catalog_material_to_project(pid, first, 2)
        db.add_catalog_material_to_project(pid, first, 3)
        db.add_catalog_material_to_project(pid, second, 4)
        rows = db.list_project_materials(pid)
        assert {r['lot']: r['quantity'] for r in rows} == {'L01': 5, 'L02': 4}
        assert all(r['code'] == '00123' for r in rows)
    finally:
        db.close()


def test_excel_preserves_extra_column_and_leading_zeros(tmp_path):
    path = tmp_path / 'exemplo.xlsx'
    wb = Workbook()
    ws = wb.active
    ws.append(['C\u00f3digo', 'Descri\u00e7\u00e3o', 'Unidade', 'Quantidade', 'Lote', 'Nota de campo'])
    ws.append(['00123', 'Cabo de teste', 'M', 2.5, '0007', 'EXTRA-TESTE'])
    wb.save(path)
    wb.close()
    db = Database(tmp_path / 'desitec.db')
    try:
        result = import_excel(path, db)
        assert result['materials_saved'] == 1
        row = db.search_material_catalog('00123')[0]
        assert row['lot'] == '0007'
        assert row['reference_quantity'] == 2.5
        raw = search_imported_rows(db, 'EXTRA-TESTE')
        assert raw[0]['data']['Nota de campo'] == 'EXTRA-TESTE'
    finally:
        db.close()


def test_email_body_contains_service_date_and_time():
    body = build_project_body({'project_date': '20/09/2026', 'project_time': '17:00', 'lda': 'LDA-TESTE'})
    assert '20/09/2026 17:00' in body
    assert 'LDA-TESTE' in body


def test_android_config_and_assets_exist():
    root = Path(__file__).resolve().parents[1]
    config = configparser.ConfigParser(interpolation=None)
    config.read(root / 'buildozer.spec', encoding='utf-8')
    assert config['app']['title'] == 'Desitec Max'
    assert config['app'].getint('android.minapi') <= 30
    for field in ('icon.filename', 'presplash.filename'):
        assert (root / config['app'][field]).is_file()
    metadata = json.loads((root / 'app_config.json').read_text(encoding='utf-8'))
    assert metadata['version'] == config['app']['version']
