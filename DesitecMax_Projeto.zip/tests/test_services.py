from pathlib import Path
import tempfile

from openpyxl import Workbook, load_workbook
from reportlab.pdfgen import canvas

from services.database import Database
from services.importers import import_excel, import_pdf
from services.materials_export import export_project_materials_xlsx
from services.maps_service import google_maps_search_url
from services.emailer import validate_email, build_project_subject


def test_services_roundtrip():
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        db = Database(tmp / "test.db")
        pid = db.save_project({
            "lda":"LDA-TESTE", "ntc":"1234/26", "item":"01", "address":"Rua Teste, Rio de Janeiro",
            "project_date":"20/09/2026", "project_time":"10:15", "service_description":"Teste"
        })

        xlsx = tmp / "materiais.xlsx"
        wb = Workbook()
        ws = wb.active
        ws.title = "Materiais"
        ws.append(["Código", "Descrição", "Unidade", "Quantidade", "Lote", "Observação"])
        ws.append([327185, "CRUZETA POLIESTER", "PC", 2, "L01", "Teste"])
        ws.append([329203, "PARAFUSO M16X45", "PC", 4, "L02", "Teste 2"])
        wb.save(xlsx)

        ex = import_excel(xlsx, db, pid)
        assert ex["rows_saved"] == 2
        assert ex["materials_saved"] == 2
        assert db.catalog_count() == 2

        # Reimportação atualiza o catálogo sem duplicar materiais equivalentes.
        ex2 = import_excel(xlsx, db, pid)
        assert ex2["materials_saved"] == 2
        assert db.catalog_count() == 2

        by_lot = db.search_material_catalog("L02")
        assert len(by_lot) == 1
        assert by_lot[0]["code"] == "329203"

        catalog = db.search_material_catalog("")
        cruzeta = next(r for r in catalog if r["code"] == "327185")
        parafuso = next(r for r in catalog if r["code"] == "329203")

        db.add_catalog_material_to_project(pid, cruzeta["id"], 2)
        db.add_catalog_material_to_project(pid, cruzeta["id"], 3)
        db.add_catalog_material_to_project(pid, parafuso["id"], 4)
        project_mats = db.list_project_materials(pid)
        assert len(project_mats) == 2
        cruzeta_project = next(r for r in project_mats if r["code"] == "327185")
        assert cruzeta_project["quantity"] == 5
        assert cruzeta_project["lot"] == "L01"

        exported = export_project_materials_xlsx(db, pid, tmp / "lista_exportada.xlsx")
        assert exported.exists()
        wb_check = load_workbook(exported, data_only=False)
        ws_check = wb_check["Materiais"]
        assert ws_check["A3"].value == "CÓDIGO"
        values = [ws_check.cell(row=r, column=1).value for r in range(4, ws_check.max_row + 1)]
        assert "327185" in values and "329203" in values

        pdf = tmp / "teste.pdf"
        c = canvas.Canvas(str(pdf))
        c.drawString(72, 720, "Desitec teste de leitura PDF")
        c.save()
        pr = import_pdf(pdf, db, pid)
        assert pr["pages"] == 1
        assert "Desitec" in pr["preview"]

        url = google_maps_search_url(address="Rua Capitão Rezende, Rio de Janeiro")
        assert "api=1" in url and "query=" in url
        assert validate_email("teste@example.com")
        assert not validate_email("email-invalido")
        project = db.get_project(pid)
        assert "LDA-TESTE" in build_project_subject(project)
        db.close()
    print("OK - Desitec Max 0.8.0: catálogo, lista de materiais, Excel, PDF, Maps e e-mail testados")


if __name__ == "__main__":
    test_services_roundtrip()
