"""Static and asset regressions; no claim that this executes Android."""
from pathlib import Path
import ast
import configparser
import hashlib
import json
import re
from zipfile import ZipFile

import pytest
import yaml
from PIL import Image
from ci.prepare_project import prepare

ROOT = Path(__file__).resolve().parents[1]


def config():
    result = configparser.ConfigParser(interpolation=None)
    result.read(ROOT / 'buildozer.spec', encoding='utf-8')
    return result['app']


def test_display_brand_does_not_change_install_id():
    cfg = config()
    assert cfg['title'] == 'Desitec Max'
    assert cfg['package.domain'] + '.' + cfg['package.name'] == 'br.com.desitec'
    main = (ROOT / 'main.py').read_text(encoding='utf-8')
    assert 'class DesitecApp(App)' in main
    assert 'data_dir / "desitec.db"' in main
    assert 'self.title = "Desitec Max"' in main


def test_logo_is_the_approved_asset():
    metadata = json.loads((ROOT / 'app_config.json').read_text(encoding='utf-8'))
    actual = hashlib.sha256((ROOT / 'assets/desitec_logo.png').read_bytes()).hexdigest()
    assert actual == metadata['logo_sha256']
    assert metadata['app_name'] == 'Desitec Max'


@pytest.mark.parametrize('key,expected', [
    ('icon.filename', (512, 512)),
    ('presplash.filename', (1280, 720)),
    ('icon.adaptive_foreground.filename', (432, 432)),
    ('icon.adaptive_background.filename', (432, 432)),
])
def test_all_android_images_are_valid(key, expected):
    with Image.open(ROOT / config()[key]) as image:
        assert image.format == 'PNG'
        assert image.size == expected
        image.verify()


def test_presplash_uses_the_supported_android_key():
    cfg = config()
    assert 'presplash.color' not in cfg
    assert cfg['android.presplash_color'] == '#031428'
    assert cfg.getint('android.minapi') <= 30
    assert cfg.getint('android.ndk_api') == cfg.getint('android.minapi')


def test_kv_has_one_root_and_valid_property_expressions():
    kv = (ROOT / 'desitec.kv').read_text(encoding='utf-8')
    assert kv.count('\nRootManager:') == 1
    assert "'[b]DESITEC[/b]'" not in kv
    assert kv.count('Desitec Max') >= 3
    for number, line in enumerate(kv.splitlines(), 1):
        assert '\t' not in line, f'Tab on KV line {number}'
        stripped = line.strip()
        if not stripped or stripped.startswith('#') or ':' not in stripped:
            continue
        key, value = stripped.split(':', 1)
        value = value.strip()
        if not value or key == 'id':
            continue
        ast.parse(value, filename=f'desitec.kv:{number}',
                  mode='exec' if key.startswith('on_') else 'eval')


def test_kv_is_not_auto_loaded_before_initialization():
    tree = ast.parse((ROOT / 'main.py').read_text(encoding='utf-8'))
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'DesitecApp')
    func = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'load_kv')
    assert any(isinstance(n, ast.Return) and isinstance(n.value, ast.Constant)
               and n.value.value is False for n in func.body)


def test_workflow_and_zip_name_agree():
    path = ROOT / '.github/workflows/gerar-apk.yml'
    text = path.read_text(encoding='utf-8')
    workflow = yaml.load(text, Loader=yaml.BaseLoader)
    assert workflow['name'] == 'Gerar APK Desitec Max'
    assert 'workflow_dispatch' in workflow['on']
    assert 'DesitecMax_Projeto.zip' in text
    assert 'Desitec_Corrigido.zip' not in text
    assert 'DesitecMax-Android11.apk' in text
    assert 'DesitecMax-APK' in text
    assert 'python -m pytest tests' in text
    assert '|| true' not in text
    assert 'python -m ci.smoke_ui' in text
    embedded = text.split("python - <<'PYBOOT'\n", 1)[1].split('          PYBOOT', 1)[0]
    import textwrap
    assert textwrap.dedent(embedded).strip() == (ROOT / 'ci/prepare_project.py').read_text().strip()


def test_android_dependencies_include_excel_dependency():
    requirements = config()['requirements'].split(',')
    assert 'et_xmlfile==2.0.0' in requirements
    assert not any(r.startswith(('pytest', 'reportlab')) for r in requirements)


def test_old_zip_cannot_override_updated_zip(tmp_path):
    repo = tmp_path / 'repo'
    repo.mkdir()
    (repo / 'Desitec_Corrigido.zip').write_bytes(b'old-invalid-archive')
    with ZipFile(repo / 'DesitecMax_Projeto.zip', 'w') as archive:
        for p in ROOT.rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts:
                archive.write(p, str(p.relative_to(ROOT)))
    project = prepare(repo, tmp_path / 'runner')
    assert json.loads((project / 'app_config.json').read_text())['app_name'] == 'Desitec Max'
