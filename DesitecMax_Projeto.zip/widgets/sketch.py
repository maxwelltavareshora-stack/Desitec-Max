from __future__ import annotations

from kivy.graphics import Color, Line, Rectangle, Ellipse, Triangle
from kivy.properties import StringProperty, NumericProperty, ListProperty
from kivy.uix.widget import Widget


class SketchCanvas(Widget):
    tool = StringProperty("pen")
    line_width = NumericProperty(2)
    network_type = StringProperty("MT")
    network_label = StringProperty("")
    road_name = StringProperty("")
    symbol_code = StringProperty("TRAFO_EXIST")
    objects = ListProperty([])

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._active = None
        self._start = None
        self.bind(pos=lambda *_: self.redraw(), size=lambda *_: self.redraw())
        self.redraw()

    def clear_objects(self):
        self.objects = []
        self.redraw()

    def undo(self):
        if self.objects:
            self.objects = self.objects[:-1]
            self.redraw()

    def load_objects(self, objects):
        self.objects = list(objects or [])
        self.redraw()

    def serialize(self):
        return list(self.objects)

    def on_touch_down(self, touch):
        if not self.collide_point(*touch.pos):
            return super().on_touch_down(touch)
        x, y = touch.pos
        self._start = [x, y]
        if self.tool == "pen":
            self._active = {"type": "pen", "points": [x, y], "width": float(self.line_width)}
        elif self.tool == "symbol":
            self.objects = self.objects + [{"type": "symbol", "x": x, "y": y, "code": self.symbol_code}]
            self.redraw()
            return True
        elif self.tool in {"line", "road", "network"}:
            self._active = {"type": self.tool, "x1": x, "y1": y, "x2": x, "y2": y, "width": float(self.line_width), "network_type": self.network_type, "label": self.network_label, "road_name": self.road_name}
        elif self.tool == "eraser":
            self._erase_near(x, y)
            return True
        self.redraw()
        return True

    def on_touch_move(self, touch):
        if not self._active:
            if self.tool == "eraser" and self.collide_point(*touch.pos):
                self._erase_near(*touch.pos)
                return True
            return super().on_touch_move(touch)
        x, y = touch.pos
        if self._active["type"] == "pen":
            self._active["points"].extend([x, y])
        else:
            self._active["x2"], self._active["y2"] = x, y
        self.redraw()
        return True

    def on_touch_up(self, touch):
        if self._active:
            self.objects = self.objects + [dict(self._active)]
            self._active = None
            self.redraw()
            return True
        return super().on_touch_up(touch)

    def _erase_near(self, x, y, radius=30):
        def hit(obj):
            if obj.get("type") == "symbol":
                return (obj.get("x", 0)-x)**2 + (obj.get("y", 0)-y)**2 <= radius**2
            if obj.get("type") == "pen":
                pts = obj.get("points", [])
                return any((pts[i]-x)**2 + (pts[i+1]-y)**2 <= radius**2 for i in range(0, len(pts)-1, 2))
            mx = (obj.get("x1",0)+obj.get("x2",0))/2
            my = (obj.get("y1",0)+obj.get("y2",0))/2
            return (mx-x)**2 + (my-y)**2 <= (radius*2)**2
        kept = [o for o in self.objects if not hit(o)]
        if len(kept) != len(self.objects):
            self.objects = kept
            self.redraw()

    def redraw(self):
        self.canvas.clear()
        with self.canvas:
            Color(1, 1, 1, 1)
            Rectangle(pos=self.pos, size=self.size)
            Color(.92, .94, .96, 1)
            step = 50
            x0, y0 = self.pos
            x1, y1 = x0 + self.width, y0 + self.height
            x = x0
            while x <= x1:
                Line(points=[x, y0, x, y1], width=.6)
                x += step
            y = y0
            while y <= y1:
                Line(points=[x0, y, x1, y], width=.6)
                y += step
            for obj in list(self.objects) + ([self._active] if self._active else []):
                self._draw_object(obj)

    def _draw_object(self, obj):
        if not obj:
            return
        Color(.05, .08, .12, 1)
        t = obj.get("type")
        if t == "pen":
            Line(points=obj.get("points", []), width=obj.get("width", 2), joint="round", cap="round")
        elif t == "line":
            Line(points=[obj["x1"], obj["y1"], obj["x2"], obj["y2"]], width=obj.get("width", 2))
        elif t == "road":
            x1,y1,x2,y2 = obj["x1"],obj["y1"],obj["x2"],obj["y2"]
            Line(points=[x1,y1,x2,y2], width=7)
            Color(1,1,1,1)
            Line(points=[x1,y1,x2,y2], width=4)
        elif t == "network":
            width = 4 if obj.get("network_type") == "AT" else 3 if obj.get("network_type") == "MT" else 2
            Line(points=[obj["x1"], obj["y1"], obj["x2"], obj["y2"]], width=width)
        elif t == "symbol":
            self._draw_symbol(obj.get("code", ""), obj.get("x",0), obj.get("y",0))

    def _draw_symbol(self, code, x, y):
        Color(.05, .08, .12, 1)
        if code in {"TRAFO_EXIST", "TRAFO_SUB", "TRAFO_INST"}:
            pts = [x-18,y+18, x+18,y+18, x,y, x-13,y+17, x,y, x,y-30]
            Line(points=pts, width=2)
            if code in {"TRAFO_SUB", "TRAFO_INST"}:
                Triangle(points=[x-13,y+17, x+18,y+18, x,y])
            if code == "TRAFO_INST":
                Line(points=[x-11,y-5,x-17,y-10], width=2)
                Line(points=[x-7,y-9,x-13,y-14], width=2)
        elif code == "POSTE_EXIST":
            Line(circle=(x,y,12), width=2)
        elif code == "POSTE_INST":
            Ellipse(pos=(x-10,y-10), size=(20,20))
        elif code == "POSTE_RET":
            Line(circle=(x,y,12), width=2)
            Line(points=[x-8,y-8,x+8,y+8], width=2)
            Line(points=[x+8,y-8,x-8,y+8], width=2)
        elif code == "ATERRAMENTO":
            Line(points=[x,y+18,x,y, x-12,y, x+12,y], width=2)
            Line(points=[x-8,y-6,x+8,y-6], width=2)
            Line(points=[x-4,y-12,x+4,y-12], width=2)
        else:
            Line(circle=(x,y,16), width=2)
            Line(points=[x,y-16,x,y+16], width=2)
            Line(points=[x-14,y+8,x+14,y+8], width=2)
