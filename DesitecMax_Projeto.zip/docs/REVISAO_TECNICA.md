# Revisão técnica - Desitec Max 0.8.0

## Alterações

1. Novo nome visível em metadados, buildozer.spec, main.py, telas KV e nome
   do remetente SMTP. Credenciais e identificadores de instalação preservados.
2. Logo aprovada copiada sem alteração; ícone 512x512, camadas adaptativas
   432x432 e presplash 1280x720 derivados. SHA-256 em app_config.json.
3. DesitecMax_Projeto.zip e o mesmo nome no guia, extrator e workflow. O ZIP
   antigo não tem prioridade sobre esta versão.
4. App.load_kv sobrescrito: impede carregamento implícito antes de build().
   Banco e mapas de seleção são criados antes do carregamento explicito de KV.
   resource_add_path localiza os assets mesmo fora da pasta corrente.
5. Chave presplash.color corrigida para android.presplash_color.
6. Dependência et_xmlfile explicitada com openpyxl no build Android.
7. Coordenadas zero não são tratadas como vazias; porta SMTP e validada antes
   de salvar as configurações.
8. Testes obrigatórios. Não ha `pytest || true` nem supressão de código de erro.
   Incluida verificação gráfica Linux no CI antes da compilação do APK.
9. Caches, bancos, chaves de assinatura e logs excluídos do ZIP entregue.

## Verificado localmente

- 32 testes com pytest aprovados.
- Sintaxe Python de 17 arquivos (AST e compileall).
- YAML lido e todos os blocos Bash verificados com bash -n.
- Expressões KV verificadas sintaticamente. Isso NÃO substitui carregar o KV
  no Kivy. Não foi possível instalar esse pacote neste ambiente.
- PNGs verificados; logo aprovada conferida por hash.

## Pendente

Compilação APK, teste em Android 11 e inicialização Kivy real. Também não
houve envio real de e-mail, GPS nem acesso ao GitHub do usuário. Os testes
não demonstram que todas as funções Android já estão operacionais.

## Referências primárias consultadas

Kivy - App.load_kv e chamado antes de build:
https://kivy.org/doc/stable/api-kivy.app.html
Buildozer - icones adaptativos e android.presplash_color:
https://github.com/kivy/buildozer/blob/master/buildozer/default.spec
Ambiente de compilação:
https://buildozer.readthedocs.io/en/latest/installation/
Versões oficiais:
https://github.com/kivy/buildozer/releases
https://github.com/kivy/python-for-android/releases
Receita Python fixada:
https://github.com/kivy/python-for-android/blob/v2026.05.09/pythonforandroid/recipes/python3/__init__.py
Ações oficiais do GitHub:
https://github.com/actions/setup-python
https://github.com/actions/setup-java
https://github.com/actions/upload-artifact
