# Desitec Max - instalar no Android usando o computador

Versão 0.8.0. O nome e a nova logo já estão aplicados no projeto.

IMPORTANTE: DesitecMax_Projeto.zip e código-fonte, não e um instalador.
O GitHub precisa terminar a compilação para gerar DesitecMax-Android11.apk.
Não instale o ZIP nem apenas troque sua extensão para APK.

## 1. Separe os dois arquivos novos

Baixe DesitecMax_Projeto.zip e gerar-apk-desitec-max.txt no computador.
NÃO extraia nem renomeie o ZIP neste procedimento.
A logo já esta em assets/ e configurada no app, no ícone e na abertura.
Não use o gerar-apk.txt antigo nem DesitecMax_Atualizado.zip.

## 2. Envie o ZIP ao GitHub

Entre no GitHub pelo navegador e abra seu repositório do app.
Na aba Code, volte a pasta principal e clique Add file > Upload files.
Selecione DesitecMax_Projeto.zip e confirme em Commit changes.
Salve na branch principal do repositório.

Mantenha o nome EXATO DesitecMax_Projeto.zip, sem (1) ou .zip.zip.
Não coloque o ZIP dentro de assets/ nem dentro de outra pasta.
O ZIP novo tem prioridade sobre Desitec_Corrigido.zip; não precisa apagar o antigo.
Não envie senhas, bancos pessoais nem documentos de clientes ao repositório.

## 3. Atualize a automação

Na aba Code, abra .github > workflows > gerar-apk.yml e clique no lápis.
Se o arquivo não existir, use Add file > Create new file e digite este nome:

.github/workflows/gerar-apk.yml

Abra gerar-apk-desitec-max.txt no Bloco de Notas. Use Ctrl+A e Ctrl+C.
No editor do GitHub, substitua TODO o conteúdo antigo usando Ctrl+A e Ctrl+V.
Confirme em Commit changes na branch principal.

Não basta enviar o TXT como anexo. O conteúdo deve ficar no arquivo .yml,
nesse caminho, fora do ZIP. Não crie duas cópias da mesma rotina.

## 4. Execute a rotina nova

Entre em Actions > Gerar APK Desitec Max > Run workflow.
Leia a licença Android SDK: https://developer.android.com/studio/terms .
Marque o aceite SOMENTE SE CONCORDAR e clique no botão verde Run workflow.

Esta versão inicia MANUALMENTE: enviar os arquivos não inicia a compilação.
Se a rotina estiver desativada, clique Enable workflow antes de executar.
Se ainda existir Python application, pode desativar APENAS essa rotina antiga:
Actions > Python application > menu de três pontos > Disable workflow.
Não use Re-run jobs de uma execução antiga.

A rotina extrai o ZIP, verifica arquivos/logo, executa testes e tenta abrir a
interface numa tela virtual Linux. Depois prepara SDK/NDK e compila o APK.
O teste Linux não substitui um teste no Android real.
Neste método pelo navegador você não precisa instalar Python nem SDK no PC.
O GitHub pode exigir permissão de Actions e saldo de minutos conforme a conta.

## 5. Baixe o instalador

Aguarde a execução terminar com sucesso (verde). Abra o resumo da execução
e role até Artifacts. Clique DesitecMax-APK e extraia o arquivo baixado.
Dentro estarão:

DesitecMax-Android11.apk
SHA256.txt

O ZIP de Artifacts e diferente do ZIP do projeto. O arquivo a instalar e o APK.
O artefato fica disponível por 14 dias nesta configuração.

## 6. Instale no Android

Transfira DesitecMax-Android11.apk ao celular, por exemplo, por cabo USB.
Abra-o no gerenciador de arquivos. Se o Android solicitar, autorize
"Permitir desta fonte" somente para o app que esta abrindo esse APK.
Toque Instalar e depois Abrir. Não desative o Play Protect; se houver um alerta
de segurança, registre a mensagem antes de prosseguir.

Confira Desitec Max e a nova logo no ícone, na abertura e na interface.
Esta e uma compilação de teste, não uma publicação na Play Store.

## Se aparecer erro

- Não aparece Gerar APK Desitec Max: confira o caminho
  .github/workflows/gerar-apk.yml na branch principal. O workflow dentro do ZIP
  não e executado pelo GitHub.
- Pedido de aceite do SDK: leia a licença e execute novamente com o aceite
  marcado somente se concordar.
- "Envie DesitecMax_Projeto.zip": confira nome exato e pasta principal.
- Execução vermelha: abra a PRIMEIRA etapa que falhou. Baixe
  DesitecMax-Diagnostico em Artifacts, quando disponível, e guarde o log.
  Não ignore o erro e não troque bibliotecas ao acaso.
- "App não instalado" ou conflito com Desitec antigo: pode haver diferença
  de assinatura. NÃO desinstale nem limpe os dados antigos sem backup.
  Builds debug em servidores diferentes podem usar chaves diferentes.
- Instala, mas fecha: anote modelo do celular, versão do Android e obtenha o
  log de inicialização. Compilação verde não garante todas as funções no aparelho.

## Fontes oficiais

GitHub - enviar arquivos:
https://docs.github.com/pt/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
GitHub - executar workflow manual:
https://docs.github.com/actions/managing-workflow-runs/manually-running-a-workflow
GitHub - baixar artefatos:
https://docs.github.com/pt/actions/how-tos/manage-workflow-runs/download-workflow-artifacts
Android - instalar apps externos:
https://support.google.com/android/answer/9457058?hl=pt-BR
