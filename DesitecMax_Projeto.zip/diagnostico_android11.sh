#!/usr/bin/env bash
set -eu
PACKAGE="br.com.desitec"
echo "Limpando logcat..."
adb logcat -c
echo "Tentando abrir $PACKAGE..."
adb shell monkey -p "$PACKAGE" 1 || true
echo "Mostrando erros do Android/Python. Pressione Ctrl+C para parar."
adb logcat | grep -E "AndroidRuntime|python|desitec|$PACKAGE"
