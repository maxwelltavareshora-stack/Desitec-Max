# Desitec Max 0.8.0

Projeto Python/Kivy de desenvolvimento técnico em redes de distribuição.
A logo escolhida pelo usuário esta aplicada na interface, no ícone Android
(com camadas adaptativas) e na abertura.

## Comecar

Leia GUIA_COMPUTADOR.md. Envie DesitecMax_Projeto.zip sem extrair ao GitHub,
copie a automação para .github/workflows/gerar-apk.yml FORA do ZIP e execute
Gerar APK Desitec Max. Não e necessário editar o código para aplicar a logo.

## O que foi preservado

Cadastro de serviço, croqui básico, data/hora, SQLite, catálogo e lista de
materiais por serviço, importadores Excel/PDF com texto, exportação Excel,
abertura de Google Maps, integrações GPS e SMTP existentes.

O identificador br.com.desitec, a classe DesitecApp e o arquivo desitec.db
foram mantidos intencionalmente. Não substitua globalmente esses nomes.
Isso não dispensa uma assinatura compatível para atualizar um APK existente.

## Limites desta entrega

- O ZIP contém código-fonte; não contém APK.
- 32 testes locais de serviços, preparacao e branding passaram.
- Kivy não estava instalado e não foi possível baixa-lo neste ambiente.
  Portanto, a interface NÃO foi executada localmente. O teste de inicialização
  Linux esta incluido no workflow (ci/smoke_ui.py).
- Compilação Android, ícone no launcher, GPS, seletor de documentos Android 11
  e SMTP real ainda exigem validação no aparelho/conta.
- PDF: extrai texto disponível; não faz OCR de documentos escaneados.
- A assinatura debug do GitHub não e uma chave de publicação. Uma atualização
  sobre um APK antigo exige assinatura compatível. Preserve seus dados.
- Nenhum acesso ou alteração ao GitHub do usuário foi feito nesta entrega.

## Executar no computador para desenvolver (opcional)

No Windows com Python 3.11 instalado, extraia o ZIP e abra um terminal NA PASTA
que contém main.py. Execute:

```bat
py -3.11 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe main.py
```

Isso abre uma janela de desenvolvimento; não gera o APK.

## Testes locais

```bash
python -m pip install -r requirements-ci.txt
python -m pytest tests -q
```

Teste gráfico Linux (requer Kivy, SDL/OpenGL e Xvfb):

```bash
python -m pip install -r requirements-ui.txt
xvfb-run -a python -m ci.smoke_ui
```

## Compilação Android

O workflow separa Python 3.11 (teste gráfico) de Python 3.14 (compilador).
Ferramentas fixadas: Buildozer 1.6.0, python-for-android v2026.05.09, NDK 28c,
Java 17, alvo API 35 e mínimo API 24. A compilação completa ainda precisa
ocorrer no GitHub. Essas configurações não são certificação de compatibilidade.

Referências e detalhes: docs/REVISAO_TECNICA.md.
